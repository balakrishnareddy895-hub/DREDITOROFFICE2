package com.dreditoroffice.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.DownloadListener
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.mlkit.common.MlKitException
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var scannedPdfUri: Uri? = null
    private val filePickerRequest = 4102
    private val scannerRequest = 4103
    private val savePdfRequest = 4104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.addJavascriptInterface(ScannerBridge(), "DRNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
        webView.setDownloadListener(DownloadListener { url, _, _, mimeType, _ ->
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (mimeType != null) setType(mimeType)
                }
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Unable to open download. Try saving from the page.", Toast.LENGTH_LONG).show()
            }
        })
        webView.loadUrl("file:///android_asset/index.html")
    }

    private inner class ScannerBridge {
        @JavascriptInterface
        fun startDocumentScan() {
            runOnUiThread { launchDocumentScanner() }
        }
    }

    private fun launchDocumentScanner() {
        val options = GmsDocumentScannerOptions.Builder()
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .setGalleryImportAllowed(true)
            .setPageLimit(50)
            .setResultFormats(
                GmsDocumentScannerOptions.RESULT_FORMAT_PDF,
                GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
            )
            .build()
        val scanner = GmsDocumentScanning.getClient(options)
        scanner.getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                try {
                    startIntentSenderForResult(intentSender, scannerRequest, null, 0, 0, 0)
                } catch (e: Exception) {
                    reportToPage("Document scanner could not be opened: ${e.message}")
                }
            }
            .addOnFailureListener { e ->
                val detail = if (e is MlKitException) "Scanner unavailable (code ${e.errorCode}). Update Google Play services and try again." else "Could not start scanner: ${e.localizedMessage}"
                reportToPage(detail)
            }
    }

    private fun reportToPage(message: String) {
        val safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        if (::webView.isInitialized) webView.post {
            webView.evaluateJavascript("if(window.nativeScanStatus){window.nativeScanStatus('$safe')}", null)
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated by Android, retained for scanner and WebView chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            filePickerRequest -> {
                val results = if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
                fileCallback?.onReceiveValue(results)
                fileCallback = null
            }
            scannerRequest -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val result = GmsDocumentScanningResult.fromActivityResultIntent(data)
                    val pdf = result?.pdf?.uri
                    if (pdf != null) {
                        scannedPdfUri = pdf
                        val save = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_TITLE, "DR-Scanned-Document.pdf")
                        }
                        startActivityForResult(save, savePdfRequest)
                    } else reportToPage("Scan completed, but the PDF result was not available. Try scanning again.")
                } else reportToPage("Scan cancelled.")
            }
            savePdfRequest -> {
                val source = scannedPdfUri
                val destination = if (resultCode == Activity.RESULT_OK) data?.data else null
                if (source != null && destination != null) {
                    try {
                        contentResolver.openInputStream(source)?.use { input ->
                            contentResolver.openOutputStream(destination)?.use { output -> input.copyTo(output) }
                                ?: throw IllegalStateException("Could not open the selected save location.")
                        } ?: throw IllegalStateException("Could not read the scanned PDF.")
                        reportToPage("Success! Your auto-cropped scan was saved as a PDF.")
                    } catch (e: Exception) {
                        reportToPage("Could not save PDF: ${e.localizedMessage}")
                    }
                } else reportToPage("PDF save cancelled. Your scan was not saved.")
                scannedPdfUri = null
            }
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
