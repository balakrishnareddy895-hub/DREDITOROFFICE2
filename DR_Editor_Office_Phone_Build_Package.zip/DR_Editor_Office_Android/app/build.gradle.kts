plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    // Google Play services document scanner: capture, edge detection, auto-crop and PDF export.
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0")
}

android {
    namespace = "com.dreditoroffice.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dreditoroffice.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
