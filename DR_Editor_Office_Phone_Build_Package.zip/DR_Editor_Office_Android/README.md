# DR Editor Office — Android Studio project

This is an Android WebView app shell around the first DR Editor Office prototype. It is a **source project, not a compiled APK**.

## Included in this build
- Android launcher app named DR Editor Office
- Android file picker support for selecting images
- Photo(s) to PDF (uses jsPDF from a CDN; internet is required)
- Image compression toward a chosen KB target (exact target is not guaranteed)
- KB ↔ MB unit converter
- Image preview

## Not included / not ready to claim
- Automatic document-edge detection and auto-crop
- OCR, PDF editing/merge/split, Word/Excel/PowerPoint editing
- User registration/login, cloud sync, payments, analytics or production backend
- Multi-million-user infrastructure, security review, privacy policy or Play Store compliance testing

The current HTML explicitly describes its limitations. Do not market this as a WPS Office or OKEN Scanner replacement yet.

## Build an APK using Android Studio
1. Install the current stable Android Studio on a computer.
2. Open this folder (`DR_Editor_Office_Android`) as an existing project.
3. Allow Gradle sync. Install Android SDK Platform 35 and a compatible Android SDK Build-Tools version if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the output location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. For Play Store release, create a signed release build using **Build → Generate Signed Bundle / APK**. Keep the signing key private and backed up.

## Technical notes
- Application ID: `com.dreditoroffice.app`
- Minimum Android: Android 7.0 (API 24)
- Target SDK: 35
- The PDF library is loaded from a CDN, so the first PDF conversion requires internet access.
- This environment does not have the Android SDK/Gradle build environment installed, so an APK could not be compiled here.


## Smart document scanner (added)
The Android app uses Google Play services ML Kit Document Scanner for camera capture, page-edge detection, automatic crop and perspective correction. It can scan multiple pages and exports a PDF. The app asks the user where to save the PDF through Android's document picker. The scanner UI is provided by Google Play services; no broad storage permission or direct camera permission is added to the app manifest. A working internet connection and a supported, up-to-date Google Play services installation may be required the first time.
